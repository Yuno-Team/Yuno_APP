-- Create views for policy lists

-- Popular policies view
CREATE OR REPLACE VIEW popular_policies AS
SELECT
    id,
    title,
    category,
    description,
    deadline,
    start_date,
    end_date,
    application_url,
    region,
    popularity_score,
    view_count,
    application_count as bookmark_count
FROM policies
WHERE status = 'active'
ORDER BY popularity_score DESC, view_count DESC, application_count DESC;

-- Deadline approaching policies view
CREATE OR REPLACE VIEW deadline_approaching_policies AS
SELECT
    id,
    title,
    category,
    description,
    deadline,
    start_date,
    end_date,
    application_url,
    region
FROM policies
WHERE status = 'active'
  AND deadline IS NOT NULL
  AND deadline BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '7 days'
ORDER BY deadline ASC;

-- Update policies table to ensure we have the right columns for compatibility
ALTER TABLE policies
ADD COLUMN IF NOT EXISTS bookmark_count INTEGER DEFAULT 0;