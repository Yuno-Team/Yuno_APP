-- Yuno 데이터베이스 초기화 스크립트 (정책 캐시 전용)

-- 정책 캐시 테이블 (온통청년 데이터)
CREATE TABLE IF NOT EXISTS policies (
    id VARCHAR(50) PRIMARY KEY, -- 온통청년 정책 ID
    title VARCHAR(500) NOT NULL,
    category VARCHAR(100),
    description TEXT,
    content TEXT, -- 정책 상세 내용
    deadline DATE,
    start_date DATE,
    end_date DATE,
    application_url TEXT,
    contact_info JSONB, -- 담당부서, 전화번호 등
    requirements JSONB DEFAULT '[]', -- 지원 자격
    benefits JSONB DEFAULT '[]', -- 지원 내용
    documents JSONB DEFAULT '[]', -- 필요 서류
    region JSONB DEFAULT '[]', -- 지원 지역
    target_age JSONB, -- {"min": 18, "max": 39}
    target_education JSONB DEFAULT '[]', -- 학력 조건
    budget BIGINT, -- 예산 (원)
    application_count INTEGER DEFAULT 0, -- 신청자 수
    view_count INTEGER DEFAULT 0, -- 조회수
    popularity_score DECIMAL(5,2) DEFAULT 0, -- 인기 점수
    tags JSONB DEFAULT '[]', -- 태그
    image_url TEXT,
    status VARCHAR(20) DEFAULT 'active', -- active, inactive, ended
    cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT valid_status CHECK (status IN ('active', 'inactive', 'ended'))
);

-- 정책 테이블 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_policies_category ON policies(category);
CREATE INDEX IF NOT EXISTS idx_policies_deadline ON policies(deadline);
CREATE INDEX IF NOT EXISTS idx_policies_status ON policies(status);
CREATE INDEX IF NOT EXISTS idx_policies_popularity ON policies(popularity_score DESC);
CREATE INDEX IF NOT EXISTS idx_policies_region ON policies USING GIN(region);
CREATE INDEX IF NOT EXISTS idx_policies_tags ON policies USING GIN(tags);
CREATE INDEX IF NOT EXISTS idx_policies_cached_at ON policies(cached_at);

-- 트리거: updated_at 자동 업데이트
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_policies_updated_at
    BEFORE UPDATE ON policies
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

COMMIT;